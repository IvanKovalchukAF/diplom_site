<?php $__currentLoopData = App\Categories::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <p>
    <div>
        <ul class="nav nav-pills nav-stacked">
            <li role="presentation" class="active"><a href="/categories/<?php echo e($category->id); ?>"><?php echo e($category->name); ?></a></li>
        </ul>
    </div>
    </p>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>