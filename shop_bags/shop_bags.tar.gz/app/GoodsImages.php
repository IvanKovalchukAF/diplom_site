<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class GoodsImages extends Model
{
    protected $table = 'goods_images';
}
